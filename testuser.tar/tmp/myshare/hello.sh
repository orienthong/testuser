#!/bin/bash
echo "app start"
echo -e
func (){
  echo "hello world!"
}
func
echo -e
echo "app end"
